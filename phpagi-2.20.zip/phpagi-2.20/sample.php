<?php
	
	$request = $fastagi->request;
	
	$fastagi->verbose('cool, the FastAGI server has been called!');	
	$fastagi->verbose('parametros='.$request['agi_arg_1']);
	
	$fastagi->set_variable("test", "1111");
	$fastagi->stream_file('custom/saludo');

?>